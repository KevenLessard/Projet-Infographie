//
//  Globals.h
//  interfaceExample
//
//  Created by Nicole Messier on 7/18/17.
//
//

#pragma once
#include "ofMain.h"

struct InfoWindowData{
    string windowId;
    bool deleteFlag; 
};

struct umoData{
    string umoId;
    ofVec2f position;    
};

