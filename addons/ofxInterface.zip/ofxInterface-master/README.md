# ofxInterface

[![Build Status](https://travis-ci.org/local-projects/ofxInterface.svg?branch=master)](https://travis-ci.org/local-projects/ofxInterface) [![Build status](https://ci.appveyor.com/api/projects/status/u1m369pj4mmr8xvu?svg=true)](https://ci.appveyor.com/project/armadillu/ofxinterface)

flexible and lightweight GUI helper with a scene-graph and a multitouch manager for OpenFrameworks
